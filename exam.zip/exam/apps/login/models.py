from __future__ import unicode_literals

from django.db import models

import bcrypt

# Create your models here.
class UsersManager(models.Manager):

    def currentUser(self, request):
        id = request.session['user_id']

        return User.objects.get(id=id)


    def validateRegistration(self, form_data):
        errors = []

        if len(form_data['name']) == 0:
            errors.append(" Name is required.")
        if len(form_data['username']) == 0:
            errors.append("Username is required.")
        if len(form_data['password']) == 0:
            errors.append("Password is required.")
        if form_data['password'] != form_data['password_confirmation']:
            errors.append("Password do not match.")
        if len(form_data['username']) <= 3:
            errors.append("Username is not valid.")
        if len(form_data['name']) <= 3:
            errors.append("Name is not valid.")

        return errors




    def validateLogin(self, form_data):
        errors = []

        user = User.objects.filter(username = form_data['username']).first()


        if len(form_data['username']) == 0:
            errors.append("Username is required.")
        if len(form_data['password']) == 0:
            errors.append("Password is required.")
        #if user == []:
            #errors.append('Account does not exist, please register first fool!')

        return errors


    def createUser(self, form_data):
        password = str(form_data['password'])
        hashed_pw = bcrypt.hashpw(password, bcrypt.gensalt())

        user = User.objects.create(
            name = form_data['name'],
            username = form_data['username'],
            password = hashed_pw
        )

        return user





class User(models.Model):
    name = models.CharField(max_length=300)
    username =models.CharField(max_length=1000)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UsersManager()
