from __future__ import unicode_literals

from django.db import models
from ..login.models import User

class ItemManager(models.Manager):

    def createItem(self, form_data, user):
        item = Item.objects.create(
            item = form_data['item'],
            user = user,
        )
        return item



class Item(models.Model):
    item = models.CharField(max_length=300)
    user = models.ForeignKey(User, related_name='items')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ItemManager()
