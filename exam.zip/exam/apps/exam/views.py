from django.shortcuts import render,redirect,reverse
from ..login.models import User
from .models import Item

# Create your views here.
def index(request):
    current_user = User.objects.currentUser(request)
    items = Item.objects.all()

    context = {
        'user': current_user,
        'items': items
    }
    return render(request, 'exam/index.html', context)

def create(request):

    return render(request, 'exam/create.html')
def add(request):
    print "Inside the method"
    if request.method == "POST":

        if len(request.POST['item']) != 0:
            current_user = User.objects.currentUser(request)
            item = Item.objects.createItem(request.POST, current_user)

    return redirect(reverse('success'))
def item( id):
    return render(request, 'exam/display.html')
def delete( id):

        item = Item.objects.get(id=id)
        current_user =  User.objects.currentUser(request)

        if current_user.id == item.user.id:
            item.delete()
            return redirect(reverse('success'))
