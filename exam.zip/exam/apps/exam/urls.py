from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name='success'),
    url(r'^create$', views.create, name='add-item'),
    url(r'^add$', views.add, name='item-add'),
    url(r'^delete/(?P<id>\d+)$', views.delete, name='delete'),
    url(r'^item/(?P<id>\d+)$', views.item, name='item'),
    ]
